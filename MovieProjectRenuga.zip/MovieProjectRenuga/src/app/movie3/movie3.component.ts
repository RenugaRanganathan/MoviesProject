import { Component } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-movie3',
  templateUrl: './movie3.component.html',
  styleUrls: ['./movie3.component.css']
})
export class Movie3Component {
  title='You have selected Annabelle movie';
  public image="../assets/aa.jpg";
  public hp =
    [{
      name: "Annabelle",
      year: "2014",
      director: "John R. Leonetti",
      genre: "Horror Film"
    }
    ];

  constructor(private router: Router) {
  }
  annabelle(h: any) {
    this.router.navigate(['/anna', h.name]);
  }
}
