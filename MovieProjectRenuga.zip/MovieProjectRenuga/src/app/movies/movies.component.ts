import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms'
import { Router } from '@angular/router';
import { ApiService } from '../shared/api.service';
import { MoviesModel } from './movies.model';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css'],
  providers: [ApiService]
})
export class MoviesComponent {
  formValue !: FormGroup;
  filmData: any;
  showAdd !: boolean;
  showUpdate !: boolean;
  MovieModelObj: MoviesModel = new MoviesModel();
  im="../assets/popcorn.jpg";

  constructor(private formBuilder: FormBuilder,
    private api: ApiService,
    private router:Router) {
  }

fetchmovies(m:any)
{
  this.router.navigate(['/movie',m.image,m.name,m.year,m.director,m.genre]);
}

  ngOnInit() {
    this.router.routeReuseStrategy.shouldReuseRoute=()=>false;
    this.formValue = this.formBuilder.group({
      image:[''],
      name: [''],
      year: [''],
      director: [''],
      genre: ['']
    })
    this.getAllMovies();
  }

  clickAddMovies() {
    this.formValue.reset();
    this.showAdd = true;
    this.showUpdate = false;
  }

  postMovieDetails() {
    { { this.MovieModelObj.name } }
    this.MovieModelObj.image = this.formValue.value.image;
    this.MovieModelObj.name = this.formValue.value.name;
    this.MovieModelObj.year = this.formValue.value.year;
    this.MovieModelObj.director = this.formValue.value.director;
    this.MovieModelObj.genre = this.formValue.value.genre;

    this.api.postMovie(this.MovieModelObj).subscribe(
      res => {
        console.log(res);
        alert("Movie Added Successfully!!!");
        this.getAllMovies();
        let close = document.getElementById("cancel");
        close?.click();
        this.formValue.reset();
      },
      err => {
        alert("Something Went Wrong!!!" + this.MovieModelObj.name);
        //this.getAllMovies();
      }
    )
  }

  getAllMovies() {
    this.api.getAllMovies().subscribe(
      res => {
        this.filmData = res;
      }
    )
  }

  deleteMovie(emp: any) {
    this.api.deleteMovie(emp.id).subscribe(
      res => {
        alert("Movie Deleted");
        this.getAllMovies();
      }
    )
  }

  editMovie(data: any) {
    this.MovieModelObj.id = data.id;
    this.showAdd = false;
    this.showUpdate = true;

    this.formValue.controls['image'].setValue(data.image);
    this.formValue.controls['name'].setValue(data.name);
    this.formValue.controls['year'].setValue(data.year);
    this.formValue.controls['director'].setValue(data.director);
    this.formValue.controls['genre'].setValue(data.genre);
  }

  updateMovieDetails() {
    this.MovieModelObj.image = this.formValue.value.image;
    this.MovieModelObj.name = this.formValue.value.name;
    this.MovieModelObj.year = this.formValue.value.year;
    this.MovieModelObj.director = this.formValue.value.director;
    this.MovieModelObj.genre = this.formValue.value.genre;

    this.api.updateMovie(this.MovieModelObj, this.MovieModelObj.id).subscribe(
      res => {
        console.log(res);
        alert("Movies Updated Successfully!!!");
        this.getAllMovies();
        let close = document.getElementById("cancel");
        close?.click();
        this.formValue.reset();
      },
      err => {
        alert("Something Went Wrong!!!");
      }
    )
  }

} 
