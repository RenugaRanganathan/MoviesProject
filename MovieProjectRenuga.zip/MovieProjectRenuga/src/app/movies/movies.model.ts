export class MoviesModel {
    id: number = 0;
    image:string='';
    name: string = '';
    year: string = '';
    director: string = '';
    genre: string = '';
}