import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-movie2',
  templateUrl: './movie2.component.html',
  styleUrls: ['./movie2.component.css']
})
export class Movie2Component {
  title='You have selected Vikram movie';
  public u: any;
  public image="../assets/vv.jpg";
  public hp =
    [{
      name: "Vikram",
      year: "2022",
      director: "Lokesh",
      genre: "Action Film"
    }
    ];

  constructor(private router: Router) {
  }
  vikram(h: any) {
    this.router.navigate(['/vik', h.name]);
  }
}
