import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public image="../assets/download.jpg";
  public image1="../assets/d.jpg";
  public image2="../assets/annab.jpg";
}
