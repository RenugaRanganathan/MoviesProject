import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Movie2Component } from './movie2/movie2.component';
import { Movie3Component } from './movie3/movie3.component';
import { MoviesComponent } from './movies/movies.component';
import { MoviesdataComponent } from './moviesdata/moviesdata.component';
import { ProjectMoviesComponent } from './project-movies/project-movies.component';

const routes: Routes = [
  {path:'harrypot',component:ProjectMoviesComponent},
  {path:'vik',component:Movie2Component},
  {path:'anna',component:Movie3Component},
  {path:'movie',component:MoviesComponent},
  {path:'movie/:image/:name/:year/:director/:genre',component:MoviesdataComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
