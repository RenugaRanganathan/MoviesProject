import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MoviesdataComponent } from './moviesdata.component';

describe('MoviesdataComponent', () => {
  let component: MoviesdataComponent;
  let fixture: ComponentFixture<MoviesdataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MoviesdataComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MoviesdataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
