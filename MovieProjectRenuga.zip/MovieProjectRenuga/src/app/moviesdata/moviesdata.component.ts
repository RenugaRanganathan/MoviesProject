import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-moviesdata',
  templateUrl: './moviesdata.component.html',
  styleUrls: ['./moviesdata.component.css']
})
export class MoviesdataComponent {
  public Image:any;
  public Name:any;
  public Year:any;
  public Director:any;
  public Genre:any;

  constructor(private route:ActivatedRoute)
  {
  }
    ngOnInit()
    {
      let image=this.route.snapshot.paramMap.get('image');
      this.Image=image;
      let name=this.route.snapshot.paramMap.get('name');
      this.Name=name;
       let year=this.route.snapshot.paramMap.get('year');
       this.Year=year;
       let director=this.route.snapshot.paramMap.get('director');
      this.Director=director;
       let genre=this.route.snapshot.paramMap.get('genre');
       this.Genre=genre;
    }
  
}
