import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-project-movies',
  templateUrl: './project-movies.component.html',
  styleUrls: ['./project-movies.component.css']
})
export class ProjectMoviesComponent {
  title = 'You have selected Harry poter and the philosopher stone';
  public image="../assets/cc.jpg";
  public u: any;
  public hp =
    [{
      name: "Harry Poter and the philosopher stone",
      year: "2001",
      director: "Chris Columbus",
      genre: "Fantasy Film"
    }
    ];

  constructor(private router: Router) {
  }
  harrypoter(h: any) {
    this.router.navigate(['/harrypot', h.name]);
  }
}