import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectMoviesComponent } from './project-movies.component';

describe('ProjectMoviesComponent', () => {
  let component: ProjectMoviesComponent;
  let fixture: ComponentFixture<ProjectMoviesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjectMoviesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProjectMoviesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
